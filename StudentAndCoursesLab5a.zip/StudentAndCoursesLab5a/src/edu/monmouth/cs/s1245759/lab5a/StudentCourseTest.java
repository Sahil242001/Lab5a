package edu.monmouth.cs.s1245759.lab5a;

import java.util.ArrayList;
public class StudentCourseTest 
{
	public static void main(String[] args) 
	{
		{
			 StudentList cs176Students = new StudentList();
			 ArrayList<Registration> courses = new ArrayList<Registration>();
			 
			 Student s1 = new Student ("Ahmed, Saahil", "1219200", "s1219200@monmouth.edu", "CS", 2, "E.Cesario", 1.0, 2022);

			 Student s2 = new Student ("Berardis, Anthony William", "1297598", "s1297598@monmouth.edu", "CS", 2, "R.Scherl", 1.0,2022);
			 
			 Student s3 = new Student ("Clappsy, Thomas V", "1218375", "s1218375@monmouth.edu", "CS", 2, "J.Kretsch", 1.0, 2022);
			 
			 
			 Course cs175 = new Course ("CS", "CS175", "Intro to csI");
			 
			 Course se102 = new Course ("SE", "SE102", "Intro to seI");
			 
			 Course ma130 = new Course ("MA", "MA130", "Dscrete math");
			 
			 Course cs176 = new Course ("CS", "CS176", "Intro to csII");
			 
			 
			 cs176Students.addStudent(s1);
			 
			 cs176Students.addStudent(s2);
			 
			 cs176Students.addStudent(s3);
			 
			 Registration r1 = new Registration (cs176, 60.0);
			 Registration r2 = new Registration (ma130, 32.0);
			 Registration r3 = new Registration (cs175, 54.0);
			 Registration r4 = new Registration (se102, 97.0);
			 
			 
			 s1.addRegistration(r1);
			 s1.addRegistration(r3);
			 s1.addRegistration(r4);
			 
			 s2.addRegistration(r2);
			 s2.addRegistration(r4);
			 
			 s3.addRegistration(r3);
			 
			 r1.setGrade(50.0);
			 r2.setGrade(80.0);
			 r3.setGrade(97.0);
			 r4.setGrade(90.0);
			 
			 cs175.courseDescription("Intro to CSI");
			 se102.courseDescription("Intro to SCI");
			 ma130.courseDescription("Intro to Discrete math");
			 cs176.courseDescription("Intro to CSII");
			 
			 cs176Students.listStudents();
			 
		}
	}

}
