package edu.monmouth.cs.s1245759.lab5a;
public class Registration 
{
	public Course course;
	private double grade;
	
	Registration (Course c, double g)
	{
		this.course = c;
		this.grade = g;
	}
	
	public void setGrade (double newGrade)
	{
		this.grade = newGrade;
	}
	
	public double getGrade ()
	{
		return this.getGrade();
	}
	
	public String toString()
	{
		return (this.course.toString() + "Grade: " + this.grade);
		
	}
}
